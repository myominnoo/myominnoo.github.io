#' @title Codebook: Detailed information about variables
#'
#' @description
#' \code{codebook()} provides detailed information about each variable
#' within the dataset.
#'
#' @param data dataframe
#'
#' @details
#' \code{codebook} generates the report of data structure with names,
#' data lables, types,
#' number of observations, number of observations with missing values and
#' percentage of observations with missing values.
#'
#' \strong{ANNOTATIONS}:
#'
#' Variable - Names of variables
#'
#' Label     - Labels of variables
#'
#' Type     - Types of variables
#'
#' _Obs - Counts of valid observations
#'
#' _NA  - Counts of observations with missing value
#'
#' _NA(%)    - Percentage of observations with missing value
#'
#'
#' @return
#' Codebook in data.frame format
#'
#' @references
#'
#' STATA DATA MANAGEMENT. UCLA: Statistical Consulting Group.
#' from https://stats.idre.ucla.edu/stata/seminars/stata-data-management/
#' (accessed Febrary 25, 2020).
#'
#'
#' @concept codebook summary structure layout
#'
#' @author
#'
#' For any feedback, please contact \code{Myo Minn Oo} via:
#'
#' Email: \email{dr.myominnoo@@gmail.com}
#'
#' Website: \url{https://myominnoo.github.io/}
#'
#' @examples
#' \dontrun{
#' codebook(infert)
#' codebook(iris)
#'
#' # if something else
#' codebook(iris$Species)
#'
#'
#'
#' # Example from IDRE UCLA
#' path <- "https://stats.idre.ucla.edu/stat/data/patient_pt1_stata_dm.dta"
#' hosp <- haven::read_dta(path)
#' codebook(hosp)
#'
#' library(magrittr)
#' hosp %>% labelData("Hospital Dataset Example") %>% codebook()
#' }
#'
#' @export
codebook <- function(data)
{
    .data.name <- deparse(substitute(data))
    .vars.names <- names(data)
    .vars.numeric <- c("integer", "double", "numeric")
    .vars.factor <- c("factor", "character")
    .vars.logical <- c("logical")
    .vars.date <- c("Date")

    ## if data is not data.frame, stop
    if (!is.data.frame(data))
        stop(paste0(" ... '", .data.name, "' is not data.frame ... "))

    ## get the types of variables
    .vars.type <- unlist(lapply(data, function(z) {
        .class <- class(unlist(z))[1]
        if (.class == "haven_labelled") {
            .class <- typeof(unlist(z))[1]
        }
        .class
    }))

    ## get the labels
    .vars.lbl <- paste(sapply(.vars.names, function(z) {
        .lbl <- attr(data[[z]], "label")
        .lbl <- ifelse(is.null(.lbl), "<NA>",
                       ifelse(nchar(.lbl) > 32,
                              paste0(strtrim(paste0(.lbl, collapse = ""), 32), "..."),
                              paste0(.lbl, collapse = "")))
    }))

    ## get count numbers for all observations, obs. without NA and NAs
    .obs.counts <- sapply(.vars.names, function(z)
        sum(as.numeric(!is.na(data[, z])), na.rm = TRUE))
    .na.counts <- sapply(.vars.names, function(z)
        sum(as.numeric(is.na(data[, z])), na.rm = TRUE))

    .df <- data.frame(1:length(.vars.names),
                      .vars.names, "|",
                      .vars.lbl,
                      .vars.type,
                      .obs.counts,
                      .na.counts,
                      round(.na.counts / nrow(data) * 100, 1),
        stringsAsFactors = FALSE,
        row.names = NULL
    )

    names(.df) <- c("No", "Variable", "|", "Label", "Type", "_Obs", "_NA", "_NA(%)")

    ## add dash lines
    .df <- addDashLines(.df, .vLine = 3)

    ## display output
    .txt <- paste0("Codebook: '", .data.name, "'")

    printText2(.df, .txt, .printDF = TRUE)

    ## display dataset label
    .data.lbl <- attr(data, "label")
    if (!is.null(.data.lbl)) {
        printMsg(paste0("Dataset label: ", .data.lbl))
    }

    invisible(.df)
}
