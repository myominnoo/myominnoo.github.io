#
#
#
# whitehall %>%
#     pick(agecat, smok == 2) %>%
#     strate(obs_time, all, grade, per = 1000)
#
# whitehall %>%
#     pick(agecat, smok == 2) %>%
#     xtab(grade, all, .)
#
#
#
#


# stmh(whitehall, obs_time, all, grade, strata = smok)
# whitehall %>%
#     pick(agecat, smok == 2) %>%
#     stmh(obs_time, all, sbpgrp)
