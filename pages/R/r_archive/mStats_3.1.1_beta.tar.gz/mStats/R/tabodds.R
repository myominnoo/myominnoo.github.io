#' @title Tabulation to display odds
#' @description
#' \code{tabodds} generates cross-tabulation between two variables and
#' display odds of failure \code{var_case} against a categorical
#' explanatory variable \code{var_exp}. It is used with cross-sectional
#' data.
#' @param var_case Case or outcome variable should be binary vector.
#' @param var_exp Exposure variable.
#' @param data a data frame object (Optional)
#' @param na.rm A logical value to specify missing values, <NA> in the table
#' @param rnd specify rounding of numbers. See \code{\link{round}}.
#' @param plot logical value to display plots of rates across a categorical
#' variable
#' @param print.table logical value to display formatted outputs
#' @details
#' The variable \code{var_case} should coded 1 for case and 0 for non-case.
#' A simple table illustrating cases and controls as well as odds for each
#' category is generated.
#'
#' @seealso \code{\link{mhodds}}
#' @keywords odds, odds ratio, frequency table, statistics, descriptive
#' @author Myo Minn Oo (Email: \email{dr.myominnoo@@gmail.com} |
#' Website: \url{https://myominnoo.github.io/})
#' @examples
#'
#' \dontrun{
#' tabodds(case, education, infert)
#' tabodds(case, parity, infert)
#'
#' infert1 <- recode(infert, induced, c(0, 1, 2), c(0, 1, 1))
#' tabodds(induced, education, infert1)
#' tabodds(induced, parity, infert1)
#' }

#' @export
tabodds <-  function(var_case, var_exp, data = NULL,
                     na.rm = FALSE, rnd = 3,
                     plot = TRUE,
                     print.table = TRUE)

{
    arguments <- as.list(match.call())
    exp_name <- (deparse(substitute(var_exp)))
    case_name <- (deparse(substitute(var_case)))

    if (!is.null(data)) {
        var_exp <- eval(substitute(var_exp), data)
        var_case <- eval(substitute(var_case), data)
    }

    na.rm <- ifelse(na.rm, "no", "ifany")

    t <- table(var_exp, var_case, useNA = na.rm)

    odds <- round(t[,2] / t[,1], rnd)
    t <- data.frame(cbind(t, odds = odds))
    names(t) <- c("controls", "cases", "odds")

    if (print.table) {
        printText(t,
                  paste0("Tabulation: ", exp_name, " ~ ", case_name, "\n",
                         "Note: showing odds"),
                  split = "Note:")
    }

    if (plot) {
        odds <- t[, "odds"]
        by <- as.factor(row.names(t))
        plot(by, odds, ylim = c(0, max(odds)),
             main = paste0("Odds of '", exp_name, "' among '",
                           case_name, "'"),
             xlab = exp_name,
             ylab = "Odds")
    }

    invisible(t)
}

