#' @title Tabulation to display Odds Ratios
#' @description
#' \code{mhodds} generates cross-tabulation between two variables and
#' display odds as well as Odds Ratios of failure \code{var_case}
#' against a categorical explanatory variable \code{var_exp}.
#'
#' It is used with cross-sectional as well as case-control data.
#' @param var_case Case or outcome variable should be binary vector.
#' @param var_exp Exposure variable.
#' @param data a data frame object (Optional)
#' @param ref_value a number or character representing reference value
#' @param na.rm A logical value to specify missing values, <NA> in the table
#' @param rnd specify rounding of numbers. See \code{\link{round}}.
#' @param print.table logical value to display formatted outputs
#' @details
#' The variable \code{var_case} should coded 1 for case and 0 for non-case.
#' The arugment \code{ref_value} can be used to set the reference value for
#' comparison of odds ratios.
#'
#' It produces a simple table with odds, Odds Ratio,95% CI as well as
#' p-value.
#'
#' \strong{Error Factor}
#'
#' is calcluated using the following formula:
#' \deqn{EF = exp(log(Odds Ratio) +/- 1.96 * SE}
#'
#' \deqn{SE = \sqrt{1/D1 + 1/D0 + 1/H1 + 1/H0}}
#'
#' @seealso \code{\link{tabodds}}
#' @keywords odds, odds ratio, frequency table, statistics, descriptive
#' @author Myo Minn Oo (Email: \email{dr.myominnoo@@gmail.com} |
#' Website: \url{https://myominnoo.github.io/})
#' @examples
#'
#' \dontrun{
#' ## Odds
#' tabodds(case, education, infert)
#' tabodds(case, parity, infert)
#'
#' infert1 <- recode(infert, induced, c(0, 1, 2), c(0, 1, 1))
#' tabodds(induced, education, infert1)
#' tabodds(induced, parity, infert1)
#'
#' ## Calculating Odds Ratios
#' mhodds(case, education, infert)
#' mhodds(case, education, infert, ref_value = "0-5yrs")
#' mhodds(case, parity, infert)
#' mhodds(case, parity, infert, ref_value = 1)
#'
#' mhodds(induced, education, infert1)
#' mhodds(induced, education, infert1, ref_value = "0-5yrs")
#' mhodds(induced, parity, infert1)
#' }

#' @export
mhodds <- function(var_case, var_exp, data = NULL,
                   ref_value = NULL,
                   na.rm = FALSE, rnd = 3,
                   print.table = TRUE)
{
    arguments <- as.list(match.call())
    exp_name <- (deparse(substitute(var_exp)))
    case_name <- (deparse(substitute(var_case)))

    if (!is.null(data)) {
        var_exp <- eval(substitute(var_exp), data)
        var_case <- eval(substitute(var_case), data)
    }

    na.rm <- ifelse(na.rm, "no", "ifany")

    t <- tabodds(var_case, var_exp, plot = FALSE, print.table = FALSE)

    lvl <- row.names(t)


    if (is.null(ref_value)) {
        ref_value <- lvl[2]
        ref_lvl <- lvl %in% ref_value
    } else {
        ref_lvl <- lvl %in% ref_value
        if (!any(ref_lvl)) {
            stop(" >>> Wrong Reference Value <<< ")
        }
    }

    if (length(lvl) == 2) {
        or <- calc_OR(t, ref_lvl, rnd)
    } else {
        or <- do.call(
            rbind,
            lapply(1:nrow(t), function(z) {
                if (row.names(t)[z] != ref_value) {
                    t.loop <- rbind(t[ref_lvl, ],
                                    t[z, ])
                    calc_OR(t.loop, c(TRUE, FALSE), rnd)
                }
            })
        )
    }
    t <- cbind(t[ref_lvl, ], "Reference", "", "", "")
    names(t) <- c("controls", "cases", "odds", "Odds Ratio", "[95% Conf.",
                  "Interval]", "P>Chi2")
    t <- rbind(t, or)

    if (print.table) {
        printText(
            t,
            paste0("Maximum likelihood estimates of Odds Ratios\n",
                   "Comparing '", case_name, "' across '", exp_name, "'"),
            split = "Comparing"
        )

        if (!is.null(attr(var_case, "label")) |
            !is.null(attr(var_exp, "label"))) {
            printMsg("Labels:")
            printMsg(paste0(exp_name, ": ",
                            attr(var_exp, "label"), collapse = ""))
            printMsg(paste0(case_name, ": ",
                            attr(var_case, "label"), collapse = ""))
        }
    }

    invisible(t)
}


#' @param t 2x2 table input to calaculate odds ratio of non-reference
#' @param ref_lvl logical vector to indicate where reference category is
#' @rdname mhodds
#' @export
calc_OR <- function(t, ref_lvl, rnd)
{
    odds <- t[, "odds"]
    odds_nonExp <- odds[ref_lvl]
    odds_exp <- odds[!ref_lvl]

    or <- odds_exp / odds_nonExp

    se <- sqrt( (1/t[1,1]) + (1/t[1,2]) + (1/t[2,1]) + (1/t[2,2]) )
    lower <- exp(log(or) - (1.96 * se))
    upper <- exp(log(or) + (1.96 * se))

    chi <- tryCatch({
        suppressWarnings(chisq.test(t[,-3], correct = FALSE))
    }, error = function(err) {
        return(NA)
    })

    or <- data.frame(cbind(
        sprintf(or, fmt = paste0('%#.', rnd, 'f')),
        sprintf(lower, fmt = paste0('%#.', rnd, 'f')),
        sprintf(upper, fmt = paste0('%#.', rnd, 'f')),
        sprintf(chi$p.value, fmt = '%#.5f')
    ))

    t <- t[!ref_lvl,]
    t <- cbind(t, or)
    names(t) <- c("controls", "cases", "odds", "Odds Ratio", "[95% Conf.",
                  "Interval]", "P>Chi2")
    return(t)
}
