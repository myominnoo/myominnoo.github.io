#' @title Describe data contents
#' @description
#' \code{summarize} Display codebook for all variables in dataset
#' \code{codebook} Display codebook for all variables in dataset
#' @param dataFrame a data frame object (Optional)
#' @param ... Arguments to be passed to method
#' @details
#' \code{summarize} or \code{codebook}
#'
#' examines the variable names, labels, and data to produce a codebook
#' describing the dataset.
#'
#' @import utils
#' @seealso \code{\link{ilog}}
#' @keywords codebook, summarize, data contents summary
#' @author Myo Minn Oo (Email: \email{dr.myominnoo@@gmail.com} |
#' Website: \url{https://myominnoo.github.io/})
#' @examples
#' summarize(iris)
#' codebook(infert)

#' @export
summarize <- function(dataFrame) {
  if (!is.data.frame(dataFrame)) stop()
  cat("\nData Summary of ", deparse(substitute(dataFrame)), "\n",
      "\nlabel: ", ifelse(is.null(attr(dataFrame, "label")), "<NA>",
                          attr(dataFrame, "label")),
      "\nobservations: ", nrow(dataFrame),
      "\nvariables: ", ncol(dataFrame), "\n\n", sep = "")
  f <- lapply(names(dataFrame), function(z) {
    x <- dataFrame[ ,z]
    cat(rep("-", 30),
        "\nvariable: ", z,
        "\nlabel: ", ifelse(is.null(attr(x, "label")), "<NA>", attr(x, "label")),
        "\ntype: ", as.character(typeof(x)),
        "\nmissing: ", length(x[is.na(x)]),
        sep = "")
    if (is.numeric(x)) {
      cat("\nrange: [", min(x, na.rm = TRUE), ", ", max(x, na.rm = TRUE), "]",
          "\nmean: ", mean(x, na.rm = TRUE),
          "\nstd.dev: ", sd(x, na.rm = TRUE),
          "\n10%: ", quantile(x, probs = .1, na.rm = TRUE),
          "\n25%: ", quantile(x, probs = .25, na.rm = TRUE),
          "\n50%: ", quantile(x, probs = .5, na.rm = TRUE),
          "\n75%: ", quantile(x, probs = .75, na.rm = TRUE),
          "\n90%: ", quantile(x, probs = .9, na.rm = TRUE),
          "\n",
          sep = "")
    } else {
      cat("\nunique values: ", length(unique(x)),  sep = "")
      cat("\nexamples: ", head(unique(x)), fill = TRUE, "\n")
    }
  })
}

#' @rdname summarize
#' @export
codebook <- function(...) {
  summarize(...)
}
