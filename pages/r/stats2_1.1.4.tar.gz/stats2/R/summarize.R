#' @title Describe data contents
#' @description
#' \code{summarize} Display codebook for all variables in dataset
#' \code{codebook} Display codebook for all variables in dataset
#' @param dataFrame a data frame object (Optional)
#' @param ... Arguments to be passed to method
#' @details
#' \code{summarize} or \code{codebook}
#'
#' examines the variable names, labels, and data to produce a codebook
#' describing the dataset.
#'
#' @import utils
#' @seealso \code{\link{ilog}}
#' @keywords codebook, summarize, data contents summary
#' @author Myo Minn Oo (Email: \email{dr.myominnoo@@gmail.com} |
#' Website: \url{https://myominnoo.github.io/})
#' @examples
#' summarize(iris)
#' codebook(infert)

#' @export
summarize <- function(dataFrame) {
  if (!is.data.frame(dataFrame)) stop()
  cat("\nSummary of Data Frame: ", deparse(substitute(dataFrame)), "\n",
      "\n   label: ", ifelse(is.null(attr(dataFrame, "label")), "<NA>",
                          attr(dataFrame, "label")),
      "\n     obs: ", nrow(dataFrame),
      "\n    vars: ", ncol(dataFrame), "\n\n", sep = "")
  f <- lapply(names(dataFrame), function(z) {
    x <- dataFrame[ ,z]
    cat(rep("-", 30),
        "\nvariable: ", z,
        "\n   label: ", ifelse(is.null(attr(x, "label")), "<NA>", attr(x, "label")),
        "\n    type: ", as.character(typeof(x)),
        "\n missing: ", length(x[is.na(x)]),
        sep = "")
    if (is.numeric(x)) {
      cat("\n   range: [", min(x, na.rm = TRUE), ", ", max(x, na.rm = TRUE), "]",
          "\n    mean: ", mean(x, na.rm = TRUE),
          "\n std.dev: ", sd(x, na.rm = TRUE),
          "\n     10%: ", quantile(x, probs = .1, na.rm = TRUE),
          "\n     25%: ", quantile(x, probs = .25, na.rm = TRUE),
          "\n     50%: ", quantile(x, probs = .5, na.rm = TRUE),
          "\n     75%: ", quantile(x, probs = .75, na.rm = TRUE),
          "\n     90%: ", quantile(x, probs = .9, na.rm = TRUE),
          "\n",
          sep = "")
    } else {
      cat("\nunique values: ", length(unique(x)),  sep = "")
      cat("\nexamples: ", head(unique(x)), fill = TRUE, "\n")
    }
  })
}

#' @rdname summarize
#' @export
codebook <- function(...) {
  summarize(...)
}
