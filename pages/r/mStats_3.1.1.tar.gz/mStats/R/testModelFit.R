#' @title Test the significance of overall model
#'
#' @description
#' \code{testModelFit} test significance of overall model and
#' its interpretation.
#'
#' @param model object glm or lm type
#'
#' @details
#' This test asks whether the model with predictors fits
#' significantly better than a model with just an intercept
#' (i.e., a null model).
#'
#' The test statistic is the difference between the residual deviance
#' for the model with predictors and the null model.
#' The test statistic is distributed chi-squared with degrees of
#' freedom equal to the differences in
#' degrees of freedom between the current and the null model
#' (i.e., the number of predictor variables in the model).
#'
#' \strong{Chi-squared value}
#'
#' \deqn{deviance [null model] - deviance}
#'
#' \strong{Degree of freedom}, df
#'
#' \deqn{df [null model] - df [residual]}
#'
#' P-value from Chi-squared distribution of resulting
#' Chi-squared value, degree of freedom is calculated.
#'
#' \strong{Interpretation}:
#'
#' If associated p-value of less than 0.05 tells us that
#' our model as a whole fits significantly better than an
#' empty model.
#'
#' This is sometimes called a likelihood ratio test
#' (the deviance residual is -2 x log-likelihood).
#'
#'
#' @references
#' \enumerate{
#'   \item LOGIT REGRESSION | R DATA ANALYSIS EXAMPLES. UCLA:
#'   Statistical Consulting
#'   Group. from https://stats.idre.ucla.edu/r/dae/logit-regression/
#'   (accessed September 27, 2019)
#' }
#'
#' @seealso
#'
#' \code{\link{modelDisplay}}
#'
#' @keywords
#'
#' model fit, significance of model
#'
#' @author
#'
#' For any feedback, please contact \code{Myo Minn Oo} via:
#'
#' Email: \email{dr.myominnoo@@gmail.com}
#'
#' Website: \url{https://myominnoo.github.io/}
#'
#' @examples
#' \dontrun{
#'
#' ## Example IDRE UCLA
#' # reading dataset
#' mydata <- read.csv("https://stats.idre.ucla.edu/stat/data/binary.csv")
#'
#' # checking dataset
#' codebook(mydata)
#'
#' # tabulation of outcome and exposure
#' tab(mydata, admit)
#' tab(mydata, rank)
#'
#'
#'
#' ### Logistic regression modelling
#' # Univariate
#' logit.gre <- glm(admit ~ gre, data = mydata, family = "binomial")
#'
#' # checking summary
#' summary(logit.gre)
#'
#' # generating outputs
#' modelDisplay(logit.gre)
#'
#' # test overall fit
#' testModelFit(logit.gre)
#'
#'
#'
#'
#' ## Multivariable logistic regression
#' logit.multi <- glm(admit ~ gre + gpa + factor(rank), data = mydata, family = "binomial")
#'
#' # checking summary
#' summary(logit.multi)
#'
#' # dislpaying model estimates
#' modelDisplay(logit.multi) # generates parameters
#'
#' # test overall fit
#' testModelFit(logit.multi) # test overall significant of the model
#' }

#' @export
testModelFit <- function(model) {
  df.diff <- with(model, df.null - df.residual)
  test <- with(model, null.deviance - deviance)
  p.value <- with(model,
                  pchisq(null.deviance - deviance,
                         df.null - df.residual,
                         lower.tail = FALSE))
  if (p.value < 0.05) txt <- "fits" else txt <- "does not fit"
  cat("\n    Test of Overall Model Fit\n",
      "\n        X-squared : ", test,
      "\nDegree of freedom : ", df.diff,
      "\n          P-value : ", sprintf(p.value, fmt = '%#.10f'),
      "\n   Interpretation : The model as a whole ",
      txt, " significantly better than an empty model.", sep = "")

  invisible(p.value)
}
