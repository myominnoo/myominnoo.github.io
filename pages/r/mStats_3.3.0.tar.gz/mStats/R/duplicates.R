#' @title Report and tag duplicated observations
#'
#' @description
#' \code{duplicates()} reports duplications and creates indexes.
#'
#' @param data Dataset
#' @param ... Variables to find duplications.
#' If not specified, all variables are used.
#' @param make_unique if `TRUE`, delete all duplicated records,
#' keeping all unique.
#'
#'
#'
#' @details
#'
#' Specified variables are used to search for duplications. If not
#' specified, all variables are used.
#'
#'
#' Then they are pasted as a character vector for speedy operation,
#' extract duplication data and make a report.
#'
#' The return dataset is added a new variable called \code{dup}
#' for further use.
#'
#'
#' \strong{ANNOTATIONS}:
#'
#' \code{Copies}       - nth Copies
#'
#' \code{Observations} - Number of corresponding observations
#'
#' \code{Surplus}  - Number of surplus observations
#'
#' \code{.dup_id} - indicates copies within the dataset:
#'
#' 0 = unique observations
#'
#' 2 = duplicated two times
#'
#' 3 = duplicated three times and so on ...
#'
#' It is labelled as `<Sys.Gen: # of DUPLICATED OBS>`.
#'
#' @return
#'
#' Modified dataset with additional variable \code{dup}
#'
#'
#' @import stats
#'
#'
#' @author
#'
#' For any feedback, please contact \code{Myo Minn Oo} via:
#'
#' Email: \email{dr.myominnoo@@gmail.com}
#'
#' Website: \url{https://myominnoo.github.io/}
#'
#' @examples
#'
#' ## use infert data
#' data(infert)
#' codebook(infert)
#'
#' ## find duplicates by pooled.stratum
#' duplicates(infert, pooled.stratum)
#'
#' ## find duplicates by stratum and pooled.stratum
#' duplicates(infert, stratum, pooled.stratum)
#'
#' ## find and remove duplicates by pooled.stratum
#' duplicates(infert, pooled.stratum, make_unique = TRUE)
#'
#' @export
duplicates <- function(data, ... , make_unique = NULL)
{
    ## match call arguments
    .args <- as.list(match.call())

    ## copy data to .data
    .data <- data

    ## get names of dataset and headings
    ## get number of observations
    .data_name <- .args$data
    .vars_names <- names(.data)

    ## if input is not a data.frame, stop
    if (!is.data.frame(.data)) {
        stop(paste0("`", .data_name, "` must be a data.frame"),
             call. = FALSE)
    }

    ## get variable names within three dots to search for duplicates
    .vars_dup <- enquotes(.args, c("data", "make_unique"))
    # If length is 0, then this is equal to all variables
    .vars_dup_len <- length(.vars_dup)

    ## check vars to find duplicates. If none, use all variables.
    if (.vars_dup_len == 0) {
        .vars_dup <- .vars_names
    }

    ## create expression to order data
    .data <- eval(parse(
        text = paste0(".data[with(.data, order(",
                      paste0(.vars_dup, collapse = ", "),
                      ")), ]")
    ))


    ## Process for creation of duplication report
    ## create identifiers to check duplications
    .id <- apply(.data[.vars_dup], 1, paste, collapse = " ")

    ## create seiral id with ave function
    .id_num <- ave(.id, .id, FUN = seq_along)
    ## get the last number of serial number
    .dup_obs <- sapply(.id, function(z) {
        .dup_id <- .id_num[.id == z]
        .dup_id[length(.dup_id)]
    })

    ## create table and use the categories to calculate surplus number
    .dup_obs_tbl <- table(.dup_obs)
    .dup_obs_tbl_names <- as.numeric(names(.dup_obs_tbl))
    .non_dup <- sapply(.dup_obs_tbl_names, function(z) {
        .dup_id <- .id[.dup_obs == z]
        length(.dup_id[!duplicated(.dup_id)])
    })


    ## create final table for duplication report
    .tbl <- data.frame(
        cbind("|", .dup_obs_tbl_names,
              .dup_obs_tbl, "|",
              .dup_obs_tbl - .non_dup, "|")
    )
    names(.tbl) <- c("|", "Copies", "Observations", "|", "Surplus", "|")

    ## add dash lines to report table
    .tbl <- addDashLines(.tbl, .vline = 3)

    ## generate report
    printDF(.tbl,  paste0("Duplicates in terms of ",
                          ifelse(.vars_dup_len == 0,
                                 "all variables",
                                 paste0(.vars_dup, collapse = " + "))
    ))
    printText(paste0("Number of Observations: ", nrow(.data)))


    ## Make changes to the dataset
    ## create a dup variable for indication
    .data$.dup_id <- as.numeric(.dup_obs) - 1
    attr(.data$.dup_id, "label") <- "<Sys.Gen: # of DUPLICATED OBS>"

    ## if drop is TRUE, then drop all duplications and keep all unique.
    if (!is.null(make_unique)) {
        if (make_unique) {
            .dup_drop <- .id_num == 1
            .data <- .data[.dup_drop, ]
            printText(paste0(
                sum(!.dup_drop), " duplicated observations REMOVED"
            ))
        } else {
            .dup_keep <- .id_num != 1
            .data <- .data[.dup_keep, ]
            printText(paste0(
                sum(!.dup_keep), " unique observations REMOVED"
            ))
        }
    }

    return(.data)
}
